- First You Need Like This
[![YLAS GAMERS](https://img001.prntscr.com/file/img001/0ZpQlA7UQBC3-rhiTXHerQ.png)](https://github.com/ylasgamers/tonlama)

- After Need Install Extension Python Like This
[![YLAS GAMERS](https://img001.prntscr.com/file/img001/tjRxiDmZSpCQB4qoBPZO8A.png)](https://github.com/ylasgamers/tonlama)

- Next Install Requirements On Terminal With Command Below And Enter
```
python -m pip install -r requirements.txt
```
[![YLAS GAMERS](https://img001.prntscr.com/file/img001/IpJhRn6nSqyCcTK39kumZA.png)](https://github.com/ylasgamers/tonlama)

- Next You Need Input Your Ton Address On data.txt
Example :
```
UQArm5VPWk_BasvVBHPtSP9NyO1Stpg8X3_4vRvqE6513Sjj
```
[![YLAS GAMERS](https://img001.prntscr.com/file/img001/Q01IPtSVSama13WGGEkJyQ.png)](https://github.com/ylasgamers/tonlama)

- Next You Can Run On Terminal With Command Below And Enter
- If Success Will Showing Like Image Below
```
python run.py
```
[![YLAS GAMERS](https://img001.prntscr.com/file/img001/N5DOk0vsRYq4vY_2xsAW7w.png)](https://github.com/ylasgamers/tonlama)
